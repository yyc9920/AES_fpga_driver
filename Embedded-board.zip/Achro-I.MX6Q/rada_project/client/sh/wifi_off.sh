ifconfig wlan0 down
ifconfig eth0 up
