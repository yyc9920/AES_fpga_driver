rmmod fpga_text_lcd_driver.ko
rmmod fpga_push_switch_driver.ko
rmmod up_down_pwm.ko
rmmod left_right_pwm.ko
rmmod hc-sr04_driver.ko
rmmod fpga_buzzer_driver.ko
rmmod fpga_fnd_dot_driver_arrow.ko
rmmod fpga_fnd_driver.ko
